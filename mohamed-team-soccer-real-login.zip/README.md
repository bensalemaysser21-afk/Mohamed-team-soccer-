# Mohamed Team Soccer — Real Player Login

This is a real server-side login starter. Player codes are checked by the Node/Express server and the logged-in player is stored in a server session.

## Run locally
1. Install Node.js 18+.
2. In this folder run:
   npm install
   npm start
3. Open http://localhost:3000

Test codes: MTS-001 through MTS-010.

## Important
Before public deployment, set a strong `SESSION_SECRET`.
For a production deployment where player data must survive server restarts, use persistent storage (for example a managed PostgreSQL database or a persistent disk) instead of relying on local SQLite storage.
