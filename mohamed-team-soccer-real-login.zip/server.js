const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const path = require("path");
const Database = require("better-sqlite3");

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(process.env.DB_PATH || path.join(__dirname, "data.sqlite"));

db.exec(`
CREATE TABLE IF NOT EXISTS players (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  role TEXT,
  code TEXT UNIQUE NOT NULL,
  score TEXT,
  absences INTEGER DEFAULT 0,
  level INTEGER,
  performance TEXT,
  jersey INTEGER
);
`);

const count = db.prepare("SELECT COUNT(*) AS n FROM players").get().n;
if (count === 0) {
  const insert = db.prepare(`INSERT INTO players
    (name, role, code, score, absences, level, performance, jersey)
    VALUES (@name,@role,@code,@score,@absences,@level,@performance,@jersey)`);
  const seed = db.transaction(players => players.forEach(p => insert.run(p)));
  seed([{"name": "Mohamed Ben Salem", "role": "Highest Captain", "code": "MTS-001", "score": "—", "absences": 1, "level": 7, "performance": "Excellent", "jersey": 20}, {"name": "Abdelrahman Boucenna", "role": "Second Captain", "code": "MTS-002", "score": "20/20", "absences": 7, "level": 11, "performance": "Excellent", "jersey": 10}, {"name": "Georgio Moretti", "role": "", "code": "MTS-003", "score": "20/20", "absences": 2, "level": 14, "performance": "Excellent", "jersey": 7}, {"name": "Daniel Foster", "role": "", "code": "MTS-004", "score": "19/20", "absences": 3, "level": 6, "performance": "Average", "jersey": 6}, {"name": "Yassin Haddad", "role": "", "code": "MTS-005", "score": "18.5/20", "absences": 1, "level": 12, "performance": "Excellent", "jersey": 16}, {"name": "Tenzin", "role": "", "code": "MTS-006", "score": "18.5/20", "absences": 0, "level": 19, "performance": "Excellent", "jersey": 23}, {"name": "Mohamed J", "role": "", "code": "MTS-007", "score": "17/20", "absences": 1, "level": 7, "performance": "Excellent", "jersey": 20}, {"name": "Abdelrahman Al Raifi", "role": "", "code": "MTS-008", "score": "17/20", "absences": 0, "level": 9, "performance": "Excellent", "jersey": 10}, {"name": "Jerom", "role": "", "code": "MTS-009", "score": "16/20", "absences": 0, "level": 9, "performance": "Excellent", "jersey": 19}, {"name": "Ahmed", "role": "", "code": "MTS-010", "score": "15/20", "absences": 0, "level": 15, "performance": "Excellent", "jersey": 3}]);
}

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: __dirname }),
  secret: process.env.SESSION_SECRET || "change-this-secret-before-production",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 1000*60*60*8 }
}));
app.use(express.static(path.join(__dirname, "public")));

app.post("/api/login", (req,res) => {
  const code = String(req.body.code || "").trim().toUpperCase();
  if (!code) return res.status(400).json({ok:false,message:"Please enter your player code."});

  const player = db.prepare(`
    SELECT id,name,role,code,score,absences,level,performance,jersey
    FROM players WHERE code = ?
  `).get(code);

  if (!player) return res.status(401).json({ok:false,message:"Invalid player code."});

  req.session.playerId = player.id;
  res.json({ok:true, player});
});

app.get("/api/me", (req,res) => {
  if (!req.session.playerId) return res.status(401).json({ok:false});
  const player = db.prepare(`
    SELECT id,name,role,code,score,absences,level,performance,jersey
    FROM players WHERE id = ?
  `).get(req.session.playerId);
  if (!player) return res.status(401).json({ok:false});
  res.json({ok:true,player});
});

app.post("/api/logout", (req,res) => {
  req.session.destroy(() => res.json({ok:true}));
});

app.listen(PORT, () => console.log(`Mohamed Team Soccer running on port ${PORT}`));
