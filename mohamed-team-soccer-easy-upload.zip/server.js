const http=require("http"),crypto=require("crypto");
const PORT=process.env.PORT||3000, PLAYERS=[["Mohamed Ben Salem", "Highest Captain", "MTS-001", "—", 1, 7, "Excellent", 20], ["Abdelrahman Boucenna", "Second Captain", "MTS-002", "20/20", 7, 11, "Excellent", 10], ["Georgio Moretti", "", "MTS-003", "20/20", 2, 14, "Excellent", 7], ["Daniel Foster", "", "MTS-004", "19/20", 3, 6, "Average", 6], ["Yassin Haddad", "", "MTS-005", "18.5/20", 1, 12, "Excellent", 16], ["Tenzin", "", "MTS-006", "18.5/20", 0, 19, "Excellent", 23], ["Mohamed J", "", "MTS-007", "17/20", 1, 7, "Excellent", 20], ["Abdelrahman Al Raifi", "", "MTS-008", "17/20", 0, 9, "Excellent", 10], ["Jerom", "", "MTS-009", "16/20", 0, 9, "Excellent", 19], ["Ahmed", "", "MTS-010", "15/20", 0, 15, "Excellent", 3]], sessions=new Map();
const page=`<!doctype html><html><meta name="viewport" content="width=device-width,initial-scale=1"><title>Mohamed Team Soccer</title>
<style>body{font-family:Arial;background:#0b1220;color:white;margin:0;padding:25px}main{max-width:650px;margin:auto}.card{background:#121d31;padding:25px;border-radius:18px;margin-top:40px}input,button{width:100%;padding:15px;margin-top:12px;border-radius:10px;font-size:17px;box-sizing:border-box}button{background:#287cff;color:white;border:0;font-weight:bold}.err{color:#ff8b8b}.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.stat{background:#0b1628;padding:15px;border-radius:12px}.muted{color:#9eacc2}@media(max-width:550px){.grid{grid-template-columns:1fr}}</style>
<main><h1>⚽ Mohamed Team Soccer</h1><p class="muted">Player Portal</p>
<section id="login" class="card"><h2>Player Login</h2><form id="f"><input id="c" placeholder="MTS-001" required><button>Sign in</button></form><p id="e" class="err"></p></section>
<section id="profile" class="card" style="display:none"><h2 id="n"></h2><p id="r" class="muted"></p><div class="grid">
<div class="stat">Jersey<br><b id="j"></b></div><div class="stat">Score<br><b id="s"></b></div><div class="stat">Level<br><b id="l"></b></div><div class="stat">Absences<br><b id="a"></b></div><div class="stat">Performance<br><b id="v"></b></div></div><button id="out">Log out</button></section></main>
<script>
const $=x=>document.getElementById(x);
function show(p){$("login").style.display="none";$("profile").style.display="block";$("n").textContent=p[0];$("r").textContent=p[1]||"Player";$("j").textContent=p[7];$("s").textContent=p[3];$("l").textContent=p[5];$("a").textContent=p[4];$("v").textContent=p[6]}
$("f").onsubmit=async e=>{e.preventDefault();let r=await fetch("/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code:$("c").value})}),d=await r.json();if(r.ok)show(d.player);else $("e").textContent="Invalid player code."};
$("out").onclick=async()=>{await fetch("/logout",{method:"POST"});location.reload()};
</script></html>`;
function send(res,status,data,type="application/json",headers={}){res.writeHead(status,{"Content-Type":type,...headers});res.end(data)}
function cookies(req){let o={};(req.headers.cookie||"").split(";").forEach(x=>{let i=x.indexOf("=");if(i>0)o[x.slice(0,i).trim()]=x.slice(i+1).trim()});return o}
http.createServer((req,res)=>{
if(req.method==="GET"&&req.url==="/")return send(res,200,page,"text/html");
if(req.method==="POST"&&(req.url==="/login"||req.url==="/logout")){
let b="";req.on("data",x=>b+=x);req.on("end",()=>{
if(req.url==="/logout"){let s=cookies(req).sid;sessions.delete(s);return send(res,200,'{"ok":true}',"application/json",{"Set-Cookie":"sid=; Max-Age=0; Path=/"})}
let code="";try{code=JSON.parse(b).code.trim().toUpperCase()}catch{}
let p=PLAYERS.find(x=>x[2]===code);if(!p)return send(res,401,'{"ok":false}');
let s=crypto.randomBytes(24).toString("hex");sessions.set(s,p[2]);send(res,200,JSON.stringify({ok:true,player:p}),"application/json",{"Set-Cookie":`sid=${s}; HttpOnly; SameSite=Lax; Path=/; Max-Age=28800`})
})}else send(res,404,"Not found","text/plain")
}).listen(PORT,()=>console.log("Running on "+PORT));